require "test_helper"

class ReservationsControllerTest < ActionDispatch::IntegrationTest

end
