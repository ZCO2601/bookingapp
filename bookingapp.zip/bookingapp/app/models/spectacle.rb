class Spectacle < ApplicationRecord
end
